﻿using RealEstate.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RealEstate.Controllers
{
    public class OwnerController : Controller
    {
        // GET: Owner
        private RealEstateContext realEstateContexts = new RealEstateContext();
        public ActionResult Index()
        {
            List<Owner> AllOwners = realEstateContexts.owners.ToList();
            return View(AllOwners);
        }

        public ActionResult Create()//Load
        { //Dropdown list 
            ViewBag.OwnerDetails = realEstateContexts.owners;
            return View();

        }
        [HttpPost]
        public ActionResult Create(Owner owner)//Insert
        {
            ViewBag.DeptDetails = realEstateContexts.owners;
            realEstateContexts.owners.Add(owner);
            realEstateContexts.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Details(String id)
        {
            Owner owner = realEstateContexts.owners.SingleOrDefault(x => x.OwnerNo == id);
            return View(owner);
        }
        public ActionResult Edit(String id)
        {
            Owner owner = realEstateContexts.owners.SingleOrDefault(x => x.OwnerNo == id);
            ViewBag.OwnerDetails = new SelectList(realEstateContexts.owners);
            return View(owner);
        }
        [HttpPost]
        public ActionResult Edit(String id, Owner updatedOwner)
        {
            Owner owner = realEstateContexts.owners.SingleOrDefault(x => x.OwnerNo == id);
            owner.Fname = updatedOwner.Fname;
            owner.Lname = updatedOwner.Lname;
            owner.Address = updatedOwner.Address;
            owner.TelNo = updatedOwner.TelNo;
            realEstateContexts.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(String id)
        {
            Owner owner = realEstateContexts.owners.SingleOrDefault(x => x.OwnerNo == id);
            return View(owner);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteOwner(String id)
        {
            Owner owner = realEstateContexts.owners.SingleOrDefault(x => x.OwnerNo == id);
            realEstateContexts.owners.Remove(owner);
            realEstateContexts.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}